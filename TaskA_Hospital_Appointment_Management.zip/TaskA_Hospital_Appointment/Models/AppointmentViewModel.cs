using System.ComponentModel.DataAnnotations;

namespace TaskA_Hospital_Appointment.Models;

// Carry appointment form values between the browser and the controller.
public class AppointmentViewModel
{
    // Require the doctor identifier to be submitted with the appointment form.
    [Required]
    public int DoctorId { get; set; }

    // Require the patient's name so the appointment request can be identified.
    [Required]
    [StringLength(100)]
    public string PatientName { get; set; } = string.Empty;

    // Require a contact email address and validate its format.
    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;

    // Store an optional appointment date entered by the patient.
    [DataType(DataType.Date)]
    public DateTime? PreferredDate { get; set; }
}
