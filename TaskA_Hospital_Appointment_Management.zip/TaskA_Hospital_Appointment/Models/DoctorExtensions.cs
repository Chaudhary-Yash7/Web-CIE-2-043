namespace TaskA_Hospital_Appointment.Models;

// Define extension methods for Doctor objects.
public static class DoctorExtensions
{
    // Calculate the full consultation charge by adding a ₹100 service charge.
    public static decimal CalculateTotalCharge(this Doctor doctor)
    {
        // Return the doctor's base fee plus the fixed service charge.
        return doctor.ConsultationFee + 100m;
    }
}
