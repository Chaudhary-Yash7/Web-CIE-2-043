namespace TaskA_Hospital_Appointment.Models;

// Represent a doctor shown in the hospital appointment application.
public class Doctor
{
    // Store the unique identifier for this doctor.
    public int DoctorId { get; set; }

    // Store the doctor's display name.
    public string DoctorName { get; set; } = string.Empty;

    // Store the doctor's medical specialization.
    public string Specialization { get; set; } = string.Empty;

    // Store the doctor's professional experience in years.
    public int Experience { get; set; }

    // Store the base consultation fee in Indian rupees.
    public decimal ConsultationFee { get; set; }
}
