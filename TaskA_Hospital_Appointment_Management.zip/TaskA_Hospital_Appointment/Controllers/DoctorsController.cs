using System.Net.Http.Json; // Provide convenient asynchronous JSON deserialization helpers.
using Microsoft.AspNetCore.Mvc; // Provide MVC controller and action-result types.
using Microsoft.Extensions.Caching.Memory; // Provide IMemoryCache for the doctor list.
using TaskA_Hospital_Appointment.Models; // Import the application's doctor and appointment models.

namespace TaskA_Hospital_Appointment.Controllers;

// Handle doctor browsing, doctor details, appointment requests, and sample posts.
public class DoctorsController : Controller
{
    // Define the cache key used for the in-memory doctor list.
    private const string DoctorCacheKey = "hospital_doctor_list";

    // Keep the fixed service charge in one place for display in views.
    private const decimal ServiceCharge = 100m;

    // Provide the doctor list cache service.
    private readonly IMemoryCache _cache;

    // Provide an HTTP client for asynchronous external API calls.
    private readonly HttpClient _httpClient;

    // Create the controller and receive its dependencies from dependency injection.
    public DoctorsController(IMemoryCache cache, IHttpClientFactory httpClientFactory)
    {
        // Save the injected memory cache for use by controller actions.
        _cache = cache;

        // Create an HTTP client from the registered factory.
        _httpClient = httpClientFactory.CreateClient();
    }

    // Display all doctors, using cached data when available.
    public IActionResult Index()
    {
        // Look for a previously cached doctor list.
        if (!_cache.TryGetValue(DoctorCacheKey, out List<Doctor>? doctors) || doctors is null)
        {
            // Create sample doctor data when the cache is empty or expired.
            doctors = GetSampleDoctors();

            // Set cache options so the list expires after three minutes.
            var cacheOptions = new MemoryCacheEntryOptions()
                .SetAbsoluteExpiration(TimeSpan.FromMinutes(3));

            // Save the doctor list in memory for subsequent requests.
            _cache.Set(DoctorCacheKey, doctors, cacheOptions);
        }

        // Read the patient name from the browser cookie, if it exists.
        ViewBag.PatientName = Request.Cookies["PatientName"] ?? string.Empty;

        // Read the selected specialization from session state, if it exists.
        ViewBag.SelectedSpecialization = HttpContext.Session.GetString("SelectedSpecialization") ?? string.Empty;

        // Return the doctor list view with the cached or newly created list.
        return View(doctors);
    }

    // Display one doctor's details; the doctor ID is supplied in the query string.
    [HttpGet]
    [ResponseCache(Duration = 60, Location = ResponseCacheLocation.Any, NoStore = false)]
    public IActionResult Details([FromQuery] int doctorId)
    {
        // Find the requested doctor using the sample data source.
        var doctor = GetSampleDoctors().FirstOrDefault(d => d.DoctorId == doctorId);

        // Return a 404 response if the requested doctor does not exist.
        if (doctor is null)
        {
            return NotFound();
        }

        // Send the doctor object to the details view.
        return View(doctor);
    }

    // Save the patient's name in a cookie and selected specialization in session.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult SavePreferences(string patientName, string specialization)
    {
        // Configure the patient cookie to expire after one day.
        var cookieOptions = new CookieOptions
        {
            Expires = DateTimeOffset.UtcNow.AddDays(1),
            HttpOnly = true,
            IsEssential = true,
            SameSite = SameSiteMode.Lax
        };

        // Store the submitted patient name in the browser cookie.
        Response.Cookies.Append("PatientName", patientName ?? string.Empty, cookieOptions);

        // Store the chosen specialization in the server-side session.
        HttpContext.Session.SetString("SelectedSpecialization", specialization ?? string.Empty);

        // Redirect to the doctor list after saving the preferences.
        return RedirectToAction(nameof(Index));
    }

    // Show the appointment form for a selected doctor.
    [HttpGet]
    public IActionResult Appointment(int doctorId)
    {
        // Check whether the selected doctor exists before showing the form.
        var doctor = GetSampleDoctors().FirstOrDefault(d => d.DoctorId == doctorId);

        // Return 404 when the doctor identifier is not valid.
        if (doctor is null)
        {
            return NotFound();
        }

        // Pre-fill the hidden doctor identifier in the appointment model.
        var model = new AppointmentViewModel { DoctorId = doctor.DoctorId };

        // Display the appointment form.
        return View(model);
    }

    // Validate and accept an appointment request submitted by a patient.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Appointment(AppointmentViewModel model)
    {
        // Reject the form if its values do not satisfy the model validation rules.
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        // Confirm that the posted hidden doctor identifier refers to a real doctor.
        var doctor = GetSampleDoctors().FirstOrDefault(d => d.DoctorId == model.DoctorId);

        // Reject an appointment request for an unknown doctor.
        if (doctor is null)
        {
            return NotFound();
        }

        // Store the patient name in a cookie so it can be used on later visits.
        Response.Cookies.Append("PatientName", model.PatientName, new CookieOptions
        {
            Expires = DateTimeOffset.UtcNow.AddDays(1),
            HttpOnly = true,
            IsEssential = true,
            SameSite = SameSiteMode.Lax
        });

        // Show a confirmation message; this demo does not persist appointments to a database.
        ViewBag.Confirmation = $"Appointment request received for {doctor.DoctorName}. Total estimated charge: ₹{doctor.CalculateTotalCharge():0.00}.";

        // Return the confirmation view with the submitted appointment details.
        return View("AppointmentConfirmation", model);
    }

    // Fetch sample posts asynchronously from JSONPlaceholder and display them in a table.
    public async Task<IActionResult> Posts()
    {
        // Request the posts endpoint without blocking the web server thread.
        var posts = await _httpClient.GetFromJsonAsync<List<SamplePost>>(
            "https://jsonplaceholder.typicode.com/posts");

        // Use an empty list if the API returns no content.
        return View(posts ?? new List<SamplePost>());
    }

    // Provide a small in-memory sample dataset for the demonstration application.
    private static List<Doctor> GetSampleDoctors()
    {
        // Return representative doctors with different specializations and consultation fees.
        return new List<Doctor>
        {
            new Doctor { DoctorId = 1, DoctorName = "Dr. Asha Patel", Specialization = "Cardiology", Experience = 12, ConsultationFee = 800m },
            new Doctor { DoctorId = 2, DoctorName = "Dr. Rahul Shah", Specialization = "Dermatology", Experience = 8, ConsultationFee = 600m },
            new Doctor { DoctorId = 3, DoctorName = "Dr. Meera Desai", Specialization = "Neurology", Experience = 15, ConsultationFee = 1000m },
            new Doctor { DoctorId = 4, DoctorName = "Dr. Karan Joshi", Specialization = "Orthopedics", Experience = 10, ConsultationFee = 700m }
        };
    }

    // Represent the subset of a JSONPlaceholder post that this task displays.
    public class SamplePost
    {
        // Store the unique post identifier returned by the API.
        public int Id { get; set; }

        // Store the post title returned by the API.
        public string Title { get; set; } = string.Empty;
    }
}
