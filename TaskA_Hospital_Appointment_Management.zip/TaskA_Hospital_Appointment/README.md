# Task A — Hospital Appointment Management System

## Requirements covered
- `Doctor` model with DoctorId, DoctorName, Specialization, Experience, and ConsultationFee.
- `CalculateTotalCharge()` extension method adds a ₹100 service charge.
- Doctor directory and details page show the base fee and total fee.
- Asynchronous JSONPlaceholder posts request; post ID and title are displayed in a table.
- Cookie stores patient name; session stores selected specialization.
- Query string passes `doctorId` to the doctor details action.
- Hidden field submits `DoctorId` with the appointment form.
- Doctor details action uses response caching for 60 seconds.
- Doctor list uses `IMemoryCache` with a three-minute absolute expiration.
- Comments explain the purpose of the main code statements and view sections.

## Run the project
1. Install the .NET 8 SDK.
2. Open a terminal in the `TaskA_Hospital_Appointment` folder.
3. Run `dotnet restore`.
4. Run `dotnet run`.
5. Open the local URL printed by the application in your browser.

## Important notes
- The doctor directory uses sample in-memory data so the project can run without a database.
- The appointment form validates and confirms a request but does not persist it to a database.
- The posts page requires internet access to call `https://jsonplaceholder.typicode.com/posts`.
- Response caching is enabled for the doctor details page. In production, avoid caching personalized or sensitive responses and review cache headers for your deployment.
