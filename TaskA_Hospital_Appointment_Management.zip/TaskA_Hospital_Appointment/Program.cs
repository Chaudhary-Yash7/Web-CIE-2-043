// Import ASP.NET Core MVC services and middleware through the Web SDK's implicit usings.

// Create the application builder that collects configuration and registered services.
var builder = WebApplication.CreateBuilder(args);

// Register MVC controllers and Razor view support in the dependency injection container.
builder.Services.AddControllersWithViews();

// Register the in-memory cache used to keep the doctor list for three minutes.
builder.Services.AddMemoryCache();

// Register distributed-memory session storage for the selected specialization.
builder.Services.AddDistributedMemoryCache();

// Configure session options, including its idle timeout and cookie settings.
builder.Services.AddSession(options =>
{
    // Expire the session after 20 minutes of inactivity.
    options.IdleTimeout = TimeSpan.FromMinutes(20);

    // Prevent client-side JavaScript from reading the session cookie.
    options.Cookie.HttpOnly = true;

    // Allow the session cookie to be sent for normal same-site navigation.
    options.Cookie.IsEssential = true;
});

// Register the HTTP client factory for asynchronous external API requests.
builder.Services.AddHttpClient();

// Register response caching services for cacheable doctor details responses.
builder.Services.AddResponseCaching();

// Build the configured web application.
var app = builder.Build();

// Show a friendly error page outside development mode.
if (!app.Environment.IsDevelopment())
{
    // Route unexpected errors to the shared error endpoint.
    app.UseExceptionHandler("/Home/Error");

    // Add HTTP Strict Transport Security for production deployments.
    app.UseHsts();
}

// Redirect HTTP requests to HTTPS when HTTPS is configured.
app.UseHttpsRedirection();

// Serve static assets such as CSS files from wwwroot.
app.UseStaticFiles();

// Enable routing so incoming requests can match MVC endpoints.
app.UseRouting();

// Enable response caching middleware before MVC endpoints execute.
app.UseResponseCaching();

// Enable session state before controllers attempt to read or write it.
app.UseSession();

// Configure the default MVC route to the Doctors controller and Index action.
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Doctors}/{action=Index}/{id?}");

// Start listening for incoming HTTP requests.
app.Run();
